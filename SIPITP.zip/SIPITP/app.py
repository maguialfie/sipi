from datetime import datetime
from bs4 import BeautifulSoup
import requests 
from matplotlib import pyplot as plt 
from flask import Flask, render_template, request, session, redirect, url_for, jsonify
import requests
from flask_mysqldb import MySQL
  
app = Flask(__name__) 
app.config["TEMPLATES_AUTO_RELOAD"] = True
API_KEY = 'ENTER-YOUR-API-KEY'

#conexion bd
app.config['MYSQL_HOST'] = '127.0.0.1'
app.config['MYSQL_USER'] = 'adoo'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'sipi'
app.config['MYSQL_PORT'] = 3306
mysql = MySQL(app)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

  

#primero que se abre
@app.route('/')
def inicio():
   return render_template('index.html')


#abre distintos htmls

@app.route('/index')
def inicio1():
   return render_template('index.html')


@app.route('/casasCambio')
def casasCambio():
    return render_template('casasCambio.html')

@app.route('/cotizaciones')
def cotizaciones():  
    url = "https://www.cronista.com/MercadosOnline/monedas.html"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
    }
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')
        markets_list_section = soup.find('section', class_='marketsList')
        if markets_list_section:
            monedas_lista = markets_list_section.find('ul')
            cont = 0
            tarjetas = []
            if monedas_lista:
                for moneda in monedas_lista.find_all('li'):
                    if cont > 0:
                        nombre = moneda.find('span', class_='name').text
                        compra = moneda.find('span', class_='buy-value').text
                        venta = moneda.find('div', class_='sell').text
                        # Generate HTML card for each currency
                        tarjeta = f"""
                        <div class="card tarjeta {nombre}" style="width: 18rem; justify-content: center; align-items: center;">
                            <div class="card-body text-center">
                                <h5 class="card-title">{nombre}</h5>
                                <div class="d-flex justify-content-center align-items-center me-2"">
                                    <span class="me-2 buy">Compra: {compra}</span>
                                    <div class="line-v"></div>
                                    <span class="ms-2 ">Venta: {venta}</span>
                                </div>
                            </div>
                        </div>
                        """
                        tarjetas.append(tarjeta)
                    cont = cont + 1
                # Join all the generated cards into a single string
                tarjetas_html = "\n".join(tarjetas)
                # Render the template with the generated HTML cards
                return render_template('cotizaciones.html', tarjetas_html=tarjetas_html)
            else:
                return "No se encontró la lista de monedas en la página."
        else:
            return "No se encontró la sección de la lista de monedas en la página."
    else:
        return f"No se pudo acceder a la página. Código de estado: {response.status_code}"
   
@app.route('/historial', methods=['GET', 'POST'])
def historial():
    if request.method == 'POST': 
        try: 
            #obtiene datos
            simbol = request.form['simbol']
            url = f"https://www.alphavantage.co/query?function=FX_DAILY&from_symbol={simbol}&to_symbol=ARS&apikey=MCVG1V7B7ZBXJ8VU"
            response = requests.get(url)
            data = response.json()
            #procesa datos
            time_series = data['Time Series FX (Daily)']
            dates = list(time_series.keys())
            prices = [float(time_series[date]['4. close']) for date in dates]
            #genera grafico
            dates1=dates[:10]
            prices1=prices[:10]
            plt.figure(figsize=(10, 6))
            plt.plot(dates1[::-1], prices1[::-1], marker='o')
            plt.title('Fluctuaciones de las acciones')
            plt.xlabel('Fecha')
            plt.ylabel('Precio de cierre')
            plt.grid(True)
            plt.savefig('static/fluctuaciones.png')
            return render_template('historial.html', simbol=simbol, image_path='static/fluctuaciones.png') 
        except Exception as e: 
            return '<h1>Bad Request : {}</h1>'.format(e)
    else: 
        return render_template('historial.html') 


@app.route('/contacto')
def contacto():
    return render_template('contacto.html')

@app.route('/impuestos')
def impuestos():
    return render_template('impuestos.html')

@app.route('/planificador', methods=['POST', 'GET'])
def planificador():
    if request.method == 'POST':
        if 'username' in request.form and 'password' in request.form:
            username = request.form['username']
            password = request.form['password']

            cur = mysql.connection.cursor()
            # Consulta para verificar si el usuario y la contraseña son válidos
            cur.execute("SELECT * FROM usuarios WHERE mail = %s AND contrasenia = %s", (username, password))
            user = cur.fetchone()
            cur.close()

            if user:
                # Si el usuario y la contraseña son válidos, almacenar en la sesión
                session['username'] = username
                return redirect(url_for('contenido', username=username))
            else:
                return render_template('planificador.html', error_message='Login Error: Usuario o contraseña incorrectos.')
        
        elif 'newUsername' in request.form and 'newPassword' in request.form:
            new_username = request.form['newUsername']
            new_password = request.form['newPassword']

            # Check if the username already exists in the database
            cur = mysql.connection.cursor()
            cur.execute("SELECT * FROM usuarios WHERE mail = %s", (new_username,))
            existing_user = cur.fetchone()
            cur.close()

            if existing_user:
                # If the username already exists, show an alert
                return render_template('planificador.html', error_message='Registration Error: Cuenta ya existente.')

            # If the username doesn't exist, insert the new user into the database
            cur = mysql.connection.cursor()
            cur.execute("INSERT INTO usuarios (mail, contrasenia) VALUES (%s, %s)", (new_username, new_password))
            mysql.connection.commit()
            cur.close()

            # Store the new user in the session
            session['username'] = new_username

            # Redirect to the login page or any other page as needed
            return redirect(url_for('planificador'))

    elif 'username' in session:
        # If the user is already logged in, redirect to the content page
        return redirect(url_for('contenido', username=session['username']))

    else:
        return render_template('planificador.html')
    

@app.route('/logout', methods=['POST'])
def logout():
    # Clear the session to log out the user
    session.pop('username', None)
    return redirect(url_for('planificador'))
    
@app.route('/contenido/<username>')
def contenido(username):
    with app.app_context():
        cur = mysql.connection.cursor()
        if request.method == 'POST':
            # If it's a POST request, it means a form is submitted
            nombre_gasto = request.form['nombre_gasto']
            medio_pago = request.form['medio_pago']
            monto = request.form['monto']

            # Insert data into MySQL
            cur.execute("INSERT INTO gastosUsuarios (mail, nombreG, medio, monto) VALUES (%s, %s, %s, %s)",
                        (username, nombre_gasto, medio_pago, monto))
            
            mysql.connection.commit()

          
            cur.execute("SELECT nombreG, monto, medio FROM gastosUsuarios WHERE mail = %s", (username,))
            gastos = cur.fetchall()
            cur.close()

            return render_template('contenido.html', gastos=gastos)
        
        cur.execute("SELECT nombreG, monto, medio FROM gastosUsuarios WHERE mail = %s", (username,))
        gastos = cur.fetchall()
        cur.close()
        return render_template('contenido.html', gastos=gastos)




@app.route('/calculadora', methods=['GET', 'POST']) 
def calculadora(): 
    if request.method == 'POST': 
        try: 
            amount = request.form['amount'] 
            amount = float(amount) 
            from_c = request.form['from_c'] 
            to_c = request.form['to_c'] 
            url = 'https://www.alphavantage.co/query?function=CURRENCY_EXCHANGE_RATE&from_currency={}&to_currency={}&apikey={}'.format( 
                from_c, to_c, API_KEY) 
            response = requests.get(url=url).json() 
            rate = response['Realtime Currency Exchange Rate']['5. Exchange Rate'] 
            rate = float(rate) 
            result = rate * amount 
            from_c_code = response['Realtime Currency Exchange Rate']['1. From_Currency Code'] 
            from_c_name = response['Realtime Currency Exchange Rate']['2. From_Currency Name'] 
            to_c_code = response['Realtime Currency Exchange Rate']['3. To_Currency Code'] 
            to_c_name = response['Realtime Currency Exchange Rate']['4. To_Currency Name'] 
            time = datetime.now()
            formato_time = time.strftime("%H:%M:%S")
            return render_template('calculadora.html', result=round(result, 2), amount=amount, 
                                   from_c_code=from_c_code, from_c_name=from_c_name, 
                                   to_c_code=to_c_code, to_c_name=to_c_name, time=formato_time) 
        except Exception as e: 
            return '<h1>Bad Request : {}</h1>'.format(e) 
  
    else: 
        return render_template('calculadora.html') 
    

@app.route('/calculadoraDolares', methods=['GET', 'POST']) 
def cambioDolares():
     url = "https://www.cronista.com/MercadosOnline/monedas.html"
     headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
     }
     response = requests.get(url, headers=headers)

     if response.status_code == 200:
        soup = BeautifulSoup(response.text, 'html.parser')

        markets_list_section = soup.find('section', class_='marketsList')

        if markets_list_section:
            monedas_lista = markets_list_section.find('ul')
            cont = 0
            tasas = {}

            if monedas_lista:
                for moneda in monedas_lista.find_all('li'):
                    if cont > 0:
                        nombre = moneda.find('span', class_='name').text
                        compra = moneda.find('span', class_='buy-value')
                        if compra is not None:
                            compra_element = compra.text
                        else:
                            print("No se pudo encontrar la tasa de compra de la moneda.")
                            continue

                        s = compra_element
                        s = s.replace('$', '').replace('.', '').replace(',', '.')
                        try:
                            f = float(s)
                        except ValueError:
                            continue

                        tasas[nombre] = f
                       
                        
                        
                    cont = cont + 1

                #print("Monedas disponibles:")
                #for moneda in tasas:
                 #   print(f"{moneda}: {tasas[moneda]}")   

                # Render the template with the generated HTML cards
                if request.method == 'POST':
                    try:
                        moneda_origen = request.form['moneda_origen']
                        moneda_destino = request.form['moneda_destino']
                        cantidad = request.form['cantidad']
                        cantidad = float(cantidad)
        
        
                        if moneda_origen == 'PESO ARGENTINO':
                            resultado = cantidad / tasas[moneda_destino]
                            precio_origen=1
                        elif moneda_destino=='PESO ARGENTINO':
                            resultado= cantidad * tasas[moneda_origen]
                            precio_destino=1
                        elif moneda_origen not in tasas or moneda_destino not in tasas:
                            print("Error: una de las monedas no está en las tasas de cambio.")
                            return
                        elif moneda_origen == moneda_destino:
                            print("El monto ya está en la moneda deseada.")
                            return
                        else:
                            resultado = cantidad / tasas[moneda_origen]
                            


                        time = datetime.now()
                        formato_time = time.strftime("%H:%M:%S")
                        return render_template('calculadora.html', resultado=round(resultado, 2), cantidad=cantidad, 
                                   nombre_origen=moneda_origen, 
                                   nombre_destino=moneda_destino, time=formato_time)


                    except Exception as e: 
                        return '<h1>Bad Request : {}</h1>'.format(e) 
                        

                else: 
                    return render_template('calculadoraDolar.html')
                 
            else:
                return "No se encontró la lista de monedas en la página."
        else:
            return "No se encontró la sección de la lista de monedas en la página."
     else:
        return f"No se pudo acceder a la página. Código de estado: {response.status_code}"





  
if __name__ == "__main__": 
    app.run(debug=True) 