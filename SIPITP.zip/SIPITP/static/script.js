

//CASAS CAMBIO

function mostrarVista(vista) {
    var mapa = document.getElementById('mapa');
    var lista = document.getElementById('lista');

    if (vista === 'mapa') {
        mapa.style.display = 'block';
        lista.style.display = 'none';
    } else if (vista === 'lista') {
        mapa.style.display = 'none';
        lista.style.display = 'block';
    }


}


//PLANIFICADO

function showRegistrationForm() {
  // Hide the login form and show the registration form
  document.getElementById('login-form').style.display = 'none';
  document.getElementById('registration-form').style.display = 'block';
}

function showLoginForm() {
  // Hide the registration form and show the login form
  document.getElementById('registration-form').style.display = 'none';
  document.getElementById('login-form').style.display = 'block';
}

  
//CONTENIDO
function toggleForm() {
    var contenidoSection = document.getElementById("contenidoSection");
    var formaAgregar = document.getElementById("formaAgregar");

    if (contenidoSection.style.display === "none") {
        contenidoSection.style.display = "block";
        formaAgregar.style.display = "none";
    } else {
        contenidoSection.style.display = "none";
        formaAgregar.style.display = "block";
    }

}








